public class Part1 {

    public static void main(String[] args) {
            
        // Q1 - Q2
        int number = 4;

        if (number == 0) {
            System.out.println("Letter: A");
        } else if (number == 1) {
            System.out.println("Letter: B");
        } else if (number == 2) {
            System.out.println("Letter: C");
        } else if (number < 2) {
            System.out.println("Letter: D");
        } else {
            System.out.println("Letter: E");
        }


        // Q3 -- what is the output
        int i = 1;
        for (i = 1; i <= 11; i+=3) {
            if (i > 8) {
                i = i - 2;
            }
            System.out.print(i);
        }
        System.out.println(i);



        // Q4: This code will not run with i set to s.length(),
        //      since an index value of 5 is out of bounds
        // Q5: What is output when i is set to s.length() - 1
        String s = "Hello";
        for (i = s.length(); i >= 0; i--) {
            char ch = s.charAt(i);
            s += "" + ch;
        }
        System.out.println(s);


        //Q6
        int arr1[] = {5,7,0,3,2};
        int arr2[] = new int[arr1.length + 4];

        int j = 0;
        for (i = 0; i < arr2.length; i++) {
            if (j >= arr1.length) j = 0;
            arr2[i] = arr1[j];
            j++;
        }

        for (i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i]);
        }


    // Q7. What is the output of this code?
    // Q8. What does this code do?

    // recall that string.indexOf(ch) returns the index of the first occurrence of
    // ch in the string, or -1 if ch is not found

    String s1 = "test";
    String s2 = "paste";

    for (i = 0; i < s1.length(); i++) {
        char currentChar = s1.charAt(i);
        if (s2.indexOf(currentChar) == s1.indexOf(currentChar)) {
            System.out.print(currentChar);            
        }

    }

    }
}
