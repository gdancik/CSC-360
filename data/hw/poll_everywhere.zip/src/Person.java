// Q10

public class Person {
    public static int num1 = 1;
    public int num2 = 1;

    Person() {
      num1 = num1 + 1;
      num2 = num2 + 1;
    }

    public void displayNums() {
      System.out.println(num1 + " and " + num2);

    }

  public static void main(String[] args) {
        Person p1 = new Person();        
        Person p2 = new Person();
        p2.displayNums();
  }

}