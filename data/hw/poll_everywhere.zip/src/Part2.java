public class Part2 {

    public void swapNumbers(int arr[]) {
        int tmp = arr[0];
        arr[0] = arr[1];
        arr[1] = tmp;
    }

    public static void main(String[] args) {
    
     // Q9. How do I call swapNumbers?
     int numbers[] = {1,2};
   
     // Q9 Answer
     Part2 p2 = new Part2();
     p2.swapNumbers(numbers);

     // Note: this does not work because swapNumbers is non-static
     //swapNumbers(numbers);

    }
}
