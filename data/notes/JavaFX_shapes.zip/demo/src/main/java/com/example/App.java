package com.example;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class App extends Application {

    // Shape sizes (line length, rectangle width and height, circle radius)
    private static final double SHAPE_SIZE = 60;

    // Time between shapes while the mouse is held. 
    private static final double DRAW_INTERVAL_MS = 20;

    // Safety cap so a tiny interval can't freeze the UI thread in a single frame
    private static final int MAX_SHAPES_PER_FRAME = 5000;

    // Width and height of each scene
    private static final int WIDTH = 800;
    private static final int HEIGHT = 650;
    
    private Canvas canvas; // surface for rendering shapes
    private GraphicsContext gc; // required for drawing to the canvas
    private ComboBox<String> shapeSelector;

    // Current mouse position while the button is held
    private double mouseX;
    private double mouseY;

    // Position where we last finished drawing (used to interpolate along the path)
    private double prevX;
    private double prevY;

    // Frame timing state
    private long lastFrameNanos;
    private double carryNanos;

    // Runs once per frame while the mouse button is held down
    private final AnimationTimer repeatDrawer = new AnimationTimer() {
        
        // This is called every frame where timer is active (triggered by mouse click)
        // 'now' is the timestamp of the current frame in nanoseconds
        // the logic allows for repeatedly drawing shapes while the mouse 
        //      mouse button is pressed
        @Override
        public void handle(long now) {
            
            // set lastFrameNanos the first time this is called
            if (lastFrameNanos == 0) {
                lastFrameNanos = now;
                return;
            }

            // the number of nanoseconds that have elapsed since last call
            carryNanos += now - lastFrameNanos;

            // update lastFrameNanos
            lastFrameNanos = now;

            // calculate the draw interval in nanoseconds
            double intervalNanos = DRAW_INTERVAL_MS * 1_000_000.0;

            // calculate the number of shapes to draw
            int count = (int) Math.min(carryNanos / intervalNanos, MAX_SHAPES_PER_FRAME);
            if (count <= 0) {
                return;
            }

            // If we hit the cap, drop the backlog by setting carry over time to 0
            carryNanos = (count == MAX_SHAPES_PER_FRAME) ? 0 : carryNanos - count * intervalNanos;

            // Spread the shapes evenly between the last position and the current one
            for (int i = 1; i <= count; i++) {
                double t = (double) i / count;
                drawShape(prevX + (mouseX - prevX) * t, prevY + (mouseY - prevY) * t);
            }
            prevX = mouseX;
            prevY = mouseY;
        }
    };

    /**
     * Creates a welcome screen that displays a rectangle, a circle, and a rectangle,
     * with a button underneath. Clicking the button changes the scene for the given
     * stage
     * @param stage - the stage to update on the button click
     * @param newScene - the newScene to switch to on the button click
     * @return a scene with shapes and the button
     */
    public Scene createWelcomeScreen(Stage stage, Scene newScene) {
        // Shapes
        Rectangle leftRect = new Rectangle(80, 80, Color.STEELBLUE);
        Circle circle = new Circle(40, Color.TOMATO);
        Rectangle rightRect = new Rectangle(80, 80, Color.SEAGREEN);
        
        // Arrange the shapes in a row
        HBox shapeRow = new HBox(20, leftRect, circle, rightRect);
        shapeRow.setAlignment(Pos.CENTER);
        
        // Create a rectangle that will be below the button
        Rectangle movableRect = new Rectangle(80, 80, Color.BROWN);
        
        // set position (within parent at (0,0) => top left)         
        movableRect.setY(0); 
        movableRect.setX( 0);

        // add rectangle to a Pane, which allows for absolute positioning
        Pane pane = new Pane(movableRect);
        pane.setPrefHeight(200);        
        
        /**
         * Create two buttons under the shapes
         */
              
        // Clicking the first button changes the scene
        Button beginButton = new Button("Click to begin");
        beginButton.setOnAction(e -> {
            stage.setScene(newScene);
        });

        // Clicking the second button moves the rectangle
        Button moveRectangleButton = new Button ("Move rectangle");
        moveRectangleButton.setOnAction(e -> {            
            movableRect.setY(movableRect.getY() + 10);             
        });

        // Create a row containing the buttons
        HBox buttonRow = new HBox(20, beginButton, moveRectangleButton);
        buttonRow.setAlignment(Pos.CENTER);

        // Stack the row of shapes above the button which is above the pane
        VBox root = new VBox(30, shapeRow, buttonRow, pane);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        
        // create and return the scene
        Scene scene = new Scene(root, WIDTH, HEIGHT);
        return scene;
    }

    @Override
    public void start(Stage stage) {

        // Top bar: HBox containing the shape drop down
        HBox topBar = getTopBar();
        
        // Create the Canvas and corresponding Graphics Context
        canvas = new Canvas(800, 600);
        gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.DARKBLUE);
        gc.setLineWidth(2);
        


        // Pane is used since this is resizable, while canvas is not
        Pane canvasHolder = new Pane(canvas);
        canvas.widthProperty().bind(canvasHolder.widthProperty());
        canvas.heightProperty().bind(canvasHolder.heightProperty());
    
        // add event handlers
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, this::onMousePressed);
        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, this::onMouseDragged);

        // stop the Animation Timer when mouse is released 
        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> repeatDrawer.stop());

        // create border pane with topBar and canvasHolder
        BorderPane root = new BorderPane();
        root.setTop(topBar);
        root.setCenter(canvasHolder);

        // the scene for drawing
        Scene sceneDraw = new Scene(root, WIDTH, HEIGHT);

        // Use filter instead of onKeyPressed so 'space' 
        // works even when the ComboBox has focus
        sceneDraw.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.SPACE) {
                clearCanvas();
                e.consume();
            } 
        });





        // Create the welcome screen
        Scene welcome = createWelcomeScreen(stage, sceneDraw);

        stage.setScene(welcome);        
        stage.setTitle("Shape Drawer");        
        stage.show();
    }


    /**
     * Creates the topBar that includes the shape selector and instruction label
     * @return the topBar
     */
    private HBox getTopBar() {
        shapeSelector = new ComboBox<>();
        shapeSelector.getItems().addAll("Line", "Circle", "Rectangle");
        shapeSelector.setValue("Line");

        Label clearHint = new Label("Press space bar to clear");        
        
        HBox topBar = new HBox(10, new Label("Shape:"), shapeSelector, clearHint);        
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(10));
        return topBar;
    }

    /**
     * Draw shape when left mouse button is pressed
     * @param e
     */
    private void onMousePressed(MouseEvent e) {
        if (e.getButton() != MouseButton.PRIMARY) {
            return;
        }

        // set focus to the canvas
        canvas.requestFocus();
        
        // get x and y coordinates
        mouseX = prevX = e.getX();
        mouseY = prevY = e.getY();

        // immediately draw the shape
        drawShape(mouseX, mouseY); 

        // reset timing, then keep drawing while held using repeatDrawer
        lastFrameNanos = 0;        
        carryNanos = 0;
        repeatDrawer.start();
    }


    // Update mouse coordinates if mouse is dragged
    private void onMouseDragged(MouseEvent e) {
        mouseX = e.getX();
        mouseY = e.getY();
    }

    /**
     * Draw selected shape centered at (x,y)
     * @param x the x coordinate of the shape
     * @param y the y coordinate of the shape
     */
    private void drawShape(double x, double y) {
        double half = SHAPE_SIZE / 2;

        switch (shapeSelector.getValue()) {
            case "Line" -> gc.strokeLine(x - half, y, x + half, y);
            case "Circle" -> gc.strokeOval(x - half, y - half, SHAPE_SIZE, SHAPE_SIZE);
            case "Rectangle" -> gc.strokeRect(x - half, y - half, SHAPE_SIZE, SHAPE_SIZE);
            default -> { }
        }
    }

    // clears canvas
    private void clearCanvas() {
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }
 
    /**
     * Exercises
     * 
     * 1. Add a rectangle to the Welcome Screen under the button 
     *          whose width matches that of all the shapes in the 
     *          first row
     * 2. Add a keyboard shortcut so if the user presses "l", "r", or "c",
     *      this will select the line, rectangle or circle from the dropdown.
     * 2. Change the DRAW_INTERVAL_MS to 1. What does this do?
     * 3. Add a ColorPicker to the top bar that allows the user to 
     *    change the color of any shape being drawn.
     */


}

