/**
 * A functional interface has a single abstract method
 */

// Question: These interfaces are not declared public or 
//  private. What are their visibility?

/**
 * 
 * CalculateOneArg functional interface
 */
@FunctionalInterface
interface CalculateOneArg {
    // implicit abstract method
    int calculate(int x);
}

/**
 * 
 * CalculateTwoArgs functional interface
 */
@FunctionalInterface 
interface CalculateTwoArgs {
    int calculate(int x, int y);
}
