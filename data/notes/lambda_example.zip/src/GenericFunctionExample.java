/**
 * Demonstrates use of lambda expressions using the
 * built-in Function<T,R> functional interface
 * See: https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html
 
 * For more built-in functional interfaces, see:
 * https://docs.oracle.com/javase/8/docs/api/java/util/function/package-summary.html
 */
import java.util.function.Function;

public class GenericFunctionExample {

    /**
     * Prints the result from evaluating a calculation with a given 
     *      value (same function from LambdaExample; not used)
     * @param c a CalculateOneArg FunctionalInterface that performs
     *          the calculation
     * @param value the value to use in the calculation
     */
    //public static void printResult(CalculateOneArg c, int value) {
    //        System.out.println("Result: " + c.calculate(value));
    //}

    /**
     * Prints the result from applying a function to the given value 
     *      This is the same logic as the above function but using the 
     *      built-in Function<T,R> functional interface
     * @param function FunctionalInterface that takes and returns an integer
     * @param value the value to pass to the function
     */
    public static void printResult(Function<Integer, Integer> function, int value) {
        System.out.println("Result: " + function.apply(value));
    }

    public static void main(String[] args) {
        
        System.out.println("Using printResult with a lambda expression:");
        printResult(x -> x * 2, 4);
                        
    }


    
 
}



