/**
 * Demonstrates use of lambda expressions, comparing them with
 * use of an explicit named class, and an anonymous class
 */
public class LambdaExample {
    public static void main(String[] args) {

        // 1. Explicit (named) class
        final class SquareA implements CalculateOneArg {
            @Override
            public int calculate(int x) {
                return x * x;
            }
        }

        // instantiate using explicit class
        CalculateOneArg squareA = new SquareA();

        // 2. Instantiate using anonymous class
        CalculateOneArg squareB = new CalculateOneArg() {
            @Override
            public int calculate(int x) {
                return x * x;
            }
        };


        // 3. Lambda expression: shortcut for creating an object
        //      that implements a functional interface
        CalculateOneArg squareC = x -> x * x;

        /**
         * squareA, squareB, and squareC are functionally 
         * equivalent Calculate objects. For any input, they
         * all give the same output.    
         */

        // output results
        System.out.println("\nsquareA, squareB, and squareC:");
        System.out.println(squareA.calculate(3));  // 9
        System.out.println(squareB.calculate(3));  // 9
        System.out.println(squareC.calculate(3));  // 9

        System.out.println();

        /**
         * We can pass any of these Calculate objects into a method
         * that takes a CalculateOneArg argument. Note that the method calls
         * the calculate method on its argument.
         */
        System.out.println("Using printResult (squareA, squareB, squareC):");
        printResult(squareA, 3);
        printResult(squareB, 3);
        printResult(squareC, 3);

        System.out.println();
        
        /**
         * This is a common use case for lambda expressions.
         * When a method takes an argument that implements a functional
         * interface, we can use a lambda expression to create an 
         * object that implements the interface. 
         */
        System.out.println("Using printResult with lambda expressions:");
        printResult(x -> x * x, 3); // implements the square calculation
        printResult(x -> x + 2, 3); // implements an add2 calculation

        System.out.println("\nAnother lambda expression");

        /**
         * For a lambda expression with multiple arguments, parentheses are
         * required
         */
        printResult((x,y) -> x + y, 6, 2);


    }

    /**
     * prints the result from evaluating a calculation with a given 
     *      value
     * @param c a CalculateOneArg FunctionalInterface that performs
     *          the calculation
     * @param value the value to use in the calculation
     */
    public static void printResult(CalculateOneArg c, int value) {
            System.out.println("Result: " + c.calculate(value));
    }

    /**
     * prints the result from evaluating a calculation with the given 
     *      values
     * @param c a CalculateTwoArgs FunctionalInterface that performs
     *          the calculation
     * @param a the first value to use in the calculation
     * @param b the second value to use in the calculation
     */
    public static void printResult(CalculateTwoArgs c, int a, int b) {
        System.out.println("Result: " + c.calculate(a,b));
    }
}



