/**
 * 
 * Example of static methods in Java
 */
public class Methods {

    /**
     * Outputs a greeting to the console
     * 
     * @param name the name to use in the greeting
     */
    public static void greeting(String name) {
        System.out.println("Hello, I'm " + name);
    }

    /**     
     * Adds two integers and returns the result.
     *
     * @param x the first number to add
     * @param y the second number to add
     * @return the sum of x and y
     */     
    public static int add(int x, int y) {
        return x + y;
    }

    public static void main(String[] args) {
        
        // print a blank line
        System.out.println();
        
        // call the greeting function
        greeting("Tyler");
        
        // print a blank line
        System.out.println();

        // Use the add function to add two numbers

        // initialize the two numbers
        int num1 = 1;
        int num2 = 2;

        // call the add function. Add returns the sum of num1 and num2, 
        // which is assigned to sum 
        int sum = add(num1, num2);
        System.out.println("The sum of " + num1 + " and " + num2 + " is " + sum);

        // print a blank line
        System.out.println();
                            
    }
    
       /**
         * Questions:
         *      1. What happens if I output the value of x
         *          inside the add method?
         *      2. What happens if I add the following line to the code:
         *          String s = greeting("Mary");
         *      3. What happens if I add the following line to the code:
         *          add(3,7);           
         */
        
}
