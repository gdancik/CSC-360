/**
 * 
 * Example of static methods in Java with array parameters
 */
public class MethodsWithArrays {

    /**
     * Prints the elements of an array
     * @param arr the array with elements to be printed
     */
    public static void printArray(int arr[]) {
        System.out.println("The array elements are:");
        for (int a : arr) {
            System.out.println(" " + a);
        }
        System.out.println();
    }

    /**
     * Demonstrates call by reference to changes the element of arr 
     * at index i to val
     * 
     * Array elements can be changed because a reference (address) of
     * the array is passed to arr when the method is called
     * 
     * @param arr the array
     * @param i the index of the element to change
     * @param val the value to change the element to
     */
    public static void setNum(int arr[], int i, int val) {
        arr[i] = val;        
    }

    /**
     * Prints the value of an integer
     * @param x the integer to display
     */
    public static void printNum(int x) {
        System.out.println("Number is: " + x);
    }
    
    /**
     * Demonstrates call by value. The intention is to change the
     * value of number, but this does not work because the value of the 
     * variable is passed to number, rather than a reference to it
     * 
     * @param number the intended number to change      
     * @param val the value to change the element to
     */
    public static void setNum(int number, int val) {
        number = val;
    }
  
    
    public static void main(String[] args) {
        
        // print a blank line
        System.out.println();
    
        // print array of numbers
        int numbers[] = {5,8,2,4};
        printArray(numbers);
                
        // Use call by reference to change the value of one of the elements
        System.out.println("Change the element at index 2 to 0:");
        setNum(numbers, 2, 0);
        printArray(numbers); 

        // print a blank line
        System.out.println();

        
        // print an integer
        int mynumber = 17;
        printNum(mynumber);        

        // Because call by value is used for integers, mynumber does not change
        System.out.println("Change an int to 0 (doesn't work):");
        setNum(mynumber, 0);
        printNum(mynumber);
        
    }
    
       /**
         * Questions:
         *      1. Why can we have two setNum methods?         
         *      2. What happens in the setNum array method, we do the following?
         *          arr = new int[]{1,1,1};*          
         */
        
}
