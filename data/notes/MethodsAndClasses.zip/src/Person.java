/**
 * 
 * Example of a Person class
 * 
 * A class defines an object that can contain data and methods which generally
 * act on its data.
 * 
 * A class should represent one cohesive concept.
 * 
 * Classes can contain fields (to store data), methods (to to define behavior, 
 * usually acting on data), and constructors (to initialize the object).
 * 
 * Members of classes can be public (accessible from any class), or private (
 * accessible only within the same class).
 * 
 * Members can also be static, which means they belong to the class, and not any
 * individual instance or object of the class.
 * 
 * It is good practice to keep data private in order to control access, and use
 * Getter methods to get data and Setter methods to change data.
 */



public class Person {

    // static nextId is shared across all Person objects
    private static int nextId = 1;

    // each Person has their own id, first name and last name
    private int id;
    private String firstName;
    private String lastName;
    
    /**
     * Constructor to set the first and last name, and assign an id 
     *      Note that this overwrites the default no-argument constructor     
     * @param firstName - the person's first name
     * @param lastName - the person's last name
     */
    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = nextId++;
    }

    /**
     * Alternative constructor with no arguments; but in practice, we may not 
     * want this, since it allows us to create a student with no name
     */    
    public Person() {
        this.firstName = null;
        this.lastName = null;        
        this.id = nextId++;
    }
    

    /**
     * Gets the person's first name
     * @return the first name 
     */
    public String getFirstName() {
        return firstName;
    }


    /**
     * Gets the person's last name
     * @return the last name 
     */
    public String getLastName() {
        return lastName;
    }

    
    /**
     * Sets the person's first name
     * @param firstName the person's first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    /**
     * Sets the person's last name
     * @param lastName the person's last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    /**
     * Gets the person's full name (first + last)
     * @return the person's full name
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

   
    /**
     * This method overrides the toString method, which all objects have
     * The @Override annotation indicates that this method is correctly overriding
     * a parent method (otherwise you will get an error)
     * 
     * This is useful for displaying objects in a readable format
     */
    @Override
    public String toString() {
        return "Person [firstName=" + firstName + ", lastName=" + lastName +
         ", id=" + id + "]";
    }

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
          
       // print a blank line
        System.out.println();
                        
        // create a person named Steve Smith
        Person p1 = new Person("Steve", "Smith");        

        // create a person with no name!
        Person p2 = new Person();
        
        // print the person's full name
        System.out.println("Printing p1 name: " + p1.getFullName());
        
        // print a blank line
        System.out.println();
                        
        System.out.println(p1);
        System.out.println(p2);
                
        // print a blank line
        System.out.println();
    
    }
    
       /**
         * Questions:
         *      1. What does it mean that Person is a public class?
         *      2. How can I change the code to access the value of nextId?
         *      3. What does it mean that main is a public static method
         */
 
     
}




