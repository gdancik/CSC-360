// Use the Javadoc Tools extension to add Javadoc to all methods
//   (Note: you will need to fill in details)

// Type the following above a class (or method) and autocomplete to begin a 
// a Javadoc comment (you will need to add details): /**

// To generate HTML files, open a terminal and run javadoc -d docs src

public class App {
  
    public static int add_positive(int a, int b) {       
        if (a < 0 || b < 0) {
            throw new IllegalArgumentException("Values must be positive");
        }
        return a + b;
    }

  
    public static int subtract_positive(int a, int b) {
        if (a < 0 || b < 0) {
            throw new IllegalArgumentException("Values must be positive");
        }
        return a - b;
    }

    public static void main(String[] args) throws Exception {
        System.out.println();
        
        int num1 = 5;
        int num2 = 3;

        System.out.println(num1 + " + " + num2 + " is: " +
                    add_positive(num1, num2));
        System.out.println(num1 + " - " + num2 + " is: " +
                     subtract_positive(num1, num2));
        
        System.out.println();
    }
}
