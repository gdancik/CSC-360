/**
 * 
 * Demonstrates several concepts related to variables and printing
 * 
 */
public class VariablesAndPrinting {
    public static void main(String[] args) throws Exception {

        // print a blank line
        System.out.println();   

        int x;  // declare a variable named x of type int        
        x = 4; // assign the value of 4 to x
        
        String course;      // declare a variable named course of type String
        
        // Assign the string "Software Development with AI" to course
        course = "Software Development with AI"; 

        // print out the value of x, and go to the next line
        System.out.println("The value of x is " + x);

        // print out the course
        System.out.println("Welcome to " + course);

        // print a blank line
        System.out.println();
       
        /**
         * Questions:
         *      1. What happens if we do not initialize x?
         *      2. What happens if we do not declare x?
         *      3. What happens if we do not initialize course?
         *      4. What happens if we use single quotes around a string?
         */
    }
}
