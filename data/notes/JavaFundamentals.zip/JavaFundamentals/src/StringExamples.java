/**
 * 
 * Demonstrates use of Strings
 * 
 */
public class StringExamples {

    public static void main(String[] args) {
        

        // a String is a sequence of characters, with index beginning at 0
        // index:       0 1 2 3 4 5 6 7 8
        // character    E l i s a b e t h
        String name1 = "Elisabeth";
        
        /**
         * Examples of string methods 
         *   For full list see https://www.w3schools.com/java/java_ref_string.asp
         */
        
        // Use String.length() to get the length of a string
        System.out.println(name1 + " is " + name1.length() + " characters long");

        // Use String.charAt(i) to return the character at index i
        char firstChar = name1.charAt(0);
        System.out.println("The first character at index 0 is: " + firstChar);

        // Use String.toUpperCase() to return a copy of the string in upper case
        String name1_upper = name1.toUpperCase();
        System.out.println("The name in upper case is: " + name1_upper + "\n");        

        // Use String.equals(s) to compare the value of two strings
        // Do not use ==, since this tests whether the two objects are the same 
        //      (i.e., occupy the same address in memory)
        // Two people can have the same name but are different people.

        char lastChar = 'h';
        String name2 = "Elisabet" + lastChar;
        
        // Output both strings
        System.out.println("name1 is: " + name1);
        System.out.println("name2 is: " + name2);
        System.out.println(); 

        // The strings have the same value...
        System.out.println("name1.equals(name2): " + name1.equals(name2));

        // ...but are different objects in memory
        System.out.println("name1 == name2: " + (name1 == name2) );
     
        
        // end with a blank line
        System.out.println(); 
    }

       /**
         * Questions:
         *      1. What is the value of name1[3]?
         *      2. What is the value of name1.charAt(3)?          
         *      3. What is the value of name1.charAt(name1.length())                  
         *  
         */
}

