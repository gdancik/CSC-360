/**
 * 
 * Demonstrates use of an if-else statement
 * 
 */
public class BranchingIfElse {

    public static void main(String[] args) {
        
        // print a blank line
        System.out.println();
        
        /**
         * 
         * A conditional block consists of an if branch that is optionally
         * followed by 1 or more else if branches, which is optionally
         * followed by an else branch. If any single branch is executed, the
         * rest of the conditional block is skipped
         *           
         */        

        // Example: determine whether an integer is positive, negative, or 0
        int x = 0;        // declare an integer x and assign it a value
        if (x < 0) {         
            // print out that x is negative
            System.out.println("x is negative");
        } else if (x > 0) {
            // print out that x is positive
            System.out.println("x is positive");
        } else {
            // print out that x is 0
            System.out.println("x is 0");
        }

        // print a blank line
        System.out.println();

    }

        /**
         * Questions:
         *      1. What is the output when x has the value -3?
         *      2. What is the output when x is 0?
         *      3. What is the output when x is 0, and there is no else branch?
         *      4. What is the output when x is 4, and there is only an if branch?
         *  
         */

}
