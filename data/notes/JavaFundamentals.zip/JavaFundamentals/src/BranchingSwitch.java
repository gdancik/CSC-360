/**
 * 
 * Demonstrates use of a switch statement
 * 
 */
public class BranchingSwitch {

    public static void main(String[] args) {
        
        // print a blank line
        System.out.println();
        
        /**
         * 
         * A switch statement allows for execution of a block of code when
         * an expression matches a discrete value. Switch statements are 
         * considered more readable than long chain if-else-if statements.
         * A break is required to end execution, otherwise "fall-through" behavior
         * results in all subsequent case blocks being executed. The default
         * block is executed if no matching cases are found
         *           
         */        

        // Example: Output day of the week, for MTWRF abbreviations ()
        char day = 'M';
        
        switch (day) {
            case 'M' :
                System.out.println("Monday");
                break;
            case 'T' :
                System.out.println("Monday");
                break;
            case 'W' :
                System.out.println("Wednesday");
                break;
            case 'R' :
                System.out.println("Thursday");
                break;
            case 'F' :
            System.out.println("Friday");
                break;
            default :
                System.out.println("Day " + day + " not recognized");
        }

        // print a blank line
        System.out.println();

    }

        /**
         * Questions:
         *      1. What would the output be if there was no break statement in the 
         *              Monday case block?
         *      2. What would the output be if day was set to 'S'?
         *      3. What would the output be if day was set to "F"?
         *  
         */

}
