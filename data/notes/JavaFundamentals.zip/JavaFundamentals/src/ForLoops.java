/**
 * 
 * Demonstrates use of for loops
 * 
 */
public class ForLoops {

    public static void main(String[] args) {
        
        // print a blank line
        System.out.println();        

        /**
         * A for loop is usually used to repeat a block of code a certain number
         * of times, or to iterate through a collection using the index
         * 
         * The structure of the for loop is below
         * 
         * for (initialization; condition; update) {
                // block of code to be executed
         * }

         *  - the initialization is executed once at the beginning of the loop
         *   - the condition is checked before each iteration
         *   - the update is executed at the end of each iteration      
         * 
         * See https://www.geeksforgeeks.org/java/loops-in-java/         
         */

        
        /**
         * For loop to sum the numbers between 1 - 10
         */

        // initialize sum to 0
        int sum = 0;        

        // for each integer num starting at 1, as long as num is <= 10,
        // add num to the sum, and then increase num by 1
        // (i.e., for each integer num between 1 - 10, add to the sum)
        for (int num = 1; num <= 10; num++) {
            sum += num;
        }

        // output the sum
        System.out.println("The sum of 1 - 10 is: " + sum);
        
        // print a blank line
        System.out.println(); 
        

         /**
         * For loop to output a string 1 character at a time, with a blank space
         * between characters
         */

        // initialize the string
        String s = "Hello World!";

        // for each index in the string (we)
        // (i.e., index starts at 0, is incremented 1 at a time, and goes up to but 
        // does not include the length of the string)
        // ex: if the string length is 12, the index values are 0 - 11
        for (int i = 0; i < s.length(); i++) {
            // get the character at that index
            char ch = s.charAt(i);
            // output the character followed by a blank space
            System.out.print(ch + " ");
        }

        // print a blank line
        System.out.println();
        

       /**
         * Questions:
         *      1. What is the output of the second loop if the update statement
         *          is changed to i+=2?
         *      2. What is output of the second loop if the output was ch + ' '?         
         *      3. How would you rewrite the first loop as a while loop?            
         *              (for review see: https://www.w3schools.com/java/java_while_loop.asp) 
         *  
         */
       
    }

}

