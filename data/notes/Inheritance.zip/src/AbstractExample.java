import java.util.ArrayList;

/**
 * 
 * Shape is an example of an abstract class
 * Shape is the base class for Circle and Rectangle (e.g., 
 *    a Circle is-a Shape)
 */


/**
 * 
 * Shape - an abstract base class
 */
abstract class Shape {
    public String color;

    // Abstract classes can have constructors
    public Shape(String color) {
        this.color = color;
    }

    // Abstract method: Has no body and MUST be implemented by subclasses
    public abstract double calculateArea();
    
    // Concrete method: Has a body and is inherited by all subclasses
    public void displayColor() {
        System.out.println("This color of the shape is " + color);
    }
}

/**
 * Circle is a concrete subclass that extends Shape
 */
class Circle extends Shape {
    public double radius;

    /**
     * Constructor to create a Circle
     * @param color the color of the circle
     * @param radius the radius of the circle
     */
    public Circle(String color, double radius) {
        super(color); 
        this.radius = radius;
    }

    /**
     * Returns the radius of the circle 
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Calculates area of the circle -- this is required
     * because we need to implement abstract methods of the
     * parent class
     */
    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

/**
 * Rectangle is a concrete subclass that extends Shape
 */

class Rectangle extends Shape {

    // Rectangles have a width and height
    private double width;
    private double height;

    /**
     * Constructor to create a Rectangle
     * @param color the color of the circle
     * @param radius the radius of the circle
     */
    public Rectangle(String color, double width, double height) {
        super(color);
        this.width = width;
        this.height = height;
    }

     /**
     * Calculates area of the rectangle -- this is required
     * because we need to implement abstract methods of the
     * parent class
     */
    @Override
    public double calculateArea() {
        return width * height;
    }
}

/**
 * 
 * Main class to run code
 */
public class AbstractExample {
    public static void main(String[] args) {
        // You CANNOT instantiate an abstract class directly:
         //Shape genericShape = new Shape("Red"); // This will throw a compilation error

        // Polymorphism: Using reference type of parent class 'Shape'
        // Declaring an object using the abstract class is preferred unless your 
        // logic requires that you have a circle. 
        Shape myCircle = new Circle("Red", 5.0);
        Shape myRectangle = new Rectangle("Blue", 4.0, 6.0);

        // Execute concrete inherited methods
        myCircle.displayColor();
        System.out.println("Circle Area: " + myCircle.calculateArea());

        System.out.println();

        myRectangle.displayColor();
        System.out.println("Rectangle Area: " + myRectangle.calculateArea());
     
    }

    /**
     * Questions: 
     *      1. Will the code run if I add a public abstract String getName() to Shape?
     *      2. How can I output the radius of myCircle?
     *      3. How can you store a collection of shapes? 
     *      4. What is a good design for adding a Square shape?
     */
}
