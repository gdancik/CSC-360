import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



/**
 * Interface requiring implementation of getFirst and getLast
 */
interface FirstLastAccessor {
    // Abstract method (no body)
    int getFirst();
    
    // Abstract method with no body
    int getLast();
}

/**
 * 
 * MyRange class which implements the above FirstLastAccessor interface, as well
 * as the built-in Comparable interface that requires implementation
 * of a natural comparison method that is used for sorting
 * See: https://docs.oracle.com/javase/8/docs/api/java/lang/Comparable.html
 * 
 * MyRange stores a range of integers. By definition (a,b) has range b - a
 * Note: in reality we should require a <= b, but this is skipped for simplicity
 */
public class MyRange implements FirstLastAccessor, Comparable <MyRange>{
    
    private final int arr[]; // stores the two values
    private final int range; // the range    

    /**
     * Construct sets the range (a,b)
     * @param a the lower value
     * @param b the upper value
     */
    MyRange(int a, int b) {        
        arr = new int[2];
        arr[0] = a;
        arr[1] = b;
        range = b - a;
        
    }

    /** 
     * Gets the first value (required for FirstLassAccessor interface)
     * @return the first value
     */
    @Override
    public int getFirst() {
        return arr[0];
    }

    /** 
     * Gets the last value (required for FirstLassAccessor interface)
     * @return the last value
     */
    @Override
    public int getLast() {
        return arr[1];
    }

    /**
    * Gets the range 
    * @return the range of (a,b)
    */
    public int getRange() {
        return range;
    }


    /**
     * Compares this range to the otherRange
     * @param otherRange
     * @return 0 if ranges are the same; -1 if the other range is greater,
     *          and +1 if this range is greater
     */
    @Override
    public int compareTo(MyRange otherRange) {
        // see https://www.geeksforgeeks.org/java/java-integer-compare-method/
        return Integer.compare(range, otherRange.getRange()); 
    }

     /**
      * Overrides default toString method
      * @return a string corresponding to the object
      */
    @Override
    public String toString() {
        return "Range = " + range + " (" + + arr[0] + ", " + arr[1] + ")";
    }

    /**
     * Main program to test logic
     */
     public static void main(String args[]) {
        
        // print a blank line
        System.out.println();

        // Create a MyRange object and print first value
        MyRange range1 = new MyRange(4,13);
        System.out.println("first value = " + range1.getFirst());


        // Create a list of ranges (details will be discussed in another example)
        List<MyRange> ranges = new ArrayList<>();
        ranges.add(range1);
        ranges.add(new MyRange(99,100));
        ranges.add(new MyRange(-50,45));
        ranges.add(new MyRange(1,20));
        
        // this sorts the ranges from smallest to greatest
        Collections.sort(ranges);
        
        // print out the sorted ranges
        for (MyRange r : ranges) {
            System.out.println(r);
        }        
        
        // print a blank line
        System.out.println();
    }
}

