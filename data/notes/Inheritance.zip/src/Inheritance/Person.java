package Inheritance;

/**
 * 
 * Example of a Person class
 * 
 * This is identical to the previous Person example but we've added
 * a getter for the id
 * 
 */

public class Person {

    // static nextId is shared across all Person objects
    private static int nextId = 1;

    // each Person has their own id, first name and last name
    private final int id;
    private String firstName;
    private String lastName;
    
    /**
     * Constructor to set the first and last name, and assign an id 
     *      Note that this overwrites the default no-argument constructor     
     * @param firstName - the person's first name
     * @param lastName - the person's last name
     */
    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = nextId++;
    }

    /**
     * Alternative constructor with no arguments; but in practice, we may not 
     * want this, since it allows us to create a student with no name
     */    
    public Person() {
        this.firstName = null;
        this.lastName = null;        
        this.id = nextId++;
    }
    
    /**
     * Gets the person's first name
     * @return the first name 
     */
    public String getFirstName() {
        return firstName;
    }


    /**
     * Gets the person's last name
     * @return the last name 
     */
    public String getLastName() {
        return lastName;
    }

    
    /**
     * Sets the person's first name
     * @param firstName the person's first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Sets the person's last name
     * @param lastName the person's last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the person's full name (first + last)
     * @return the person's full name
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

      /**
     * Gets the person's id
     * @return the last name 
     */
    public int getId() {
        return id;
    }

    /**
     * This method overrides the toString method, which all objects have
     * The @Override annotation indicates that this method is correctly overriding
     * a parent method (otherwise you will get an error)
     * 
     * This is useful for displaying objects in a readable format
     */
    @Override
    public String toString() {
        return "Person [firstName=" + firstName + ", lastName=" + lastName +
         ", id=" + id + "]";
    }
        
}
