package Inheritance;

/**
 * Example of a Inheritance with a Student class derived from Person 
 *
 * The child class inherits all fields and methods from its parent class.
 * Methods can be overwritten.
 */ 

public class Student extends Person {

    private String major;
    
    /**
     * Constructor to set the first and last name, and assign an id 
     *      Note that this overwrites the default no-argument constructor     
     * @param firstName - the person's first name
     * @param lastName - the person's last name
     */
    public Student(String firstName, String lastName, String major) {   
        
        // call parent constructor -- this should be first (required until Java 25)
        super(firstName, lastName); 
        this.major = major;                
    }

     /**
     * Gets the person's major
     * @return the major
     */
    public String getMajor() {
        return major;
    }

    /**
     * Sets the person's major
     * @param major the person's major
     */
    public void setMajor(String major) {
        this.major = major;
    }

   
    /**
     * This method overrides the Person toString method
     */
    @Override
    public String toString() {
        return "Student [firstName=" + super.getFirstName() + 
                     ", lastName=" + super.getLastName() +
                     ", id=" + super.getId() + 
                     ", major=" + major + "]";
    }
   
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
          
       // print a blank line
        System.out.println();
                        
        // create a person named Steve Smith
        Person s1 = new Student("Steve", "Smith", "CSC");        

        // print the person's full name
        System.out.println("Printing s1 name: " + s1.getFullName());
        
        // print a blank line
        System.out.println();
        
        // print Student object (toString)
        System.out.println(s1);

        // print a blank line
        System.out.println();

        
    }

    /**
     * Questions:
     *      1. How can I add a method that determines whether two students
     *          have the same major?  
     *      2. How can I add a method to return the name using the format
     *          lastName, firstName                
     */
    
   

}
