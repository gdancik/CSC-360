package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 
 * Class for testing the Calculator class
 */
public class CalculatorTest {
    
    // instance variable for all test methods
    private Calculator calculator; 

    @BeforeEach 
    void setUp() {
        // 1. Arrange (called before all test methods)
        calculator = new Calculator();
    }

    @Test
    void testSum() {

        // 1. Arrange
        int firstNumber = 3;
        int secondNumber = 4;
        int expectedResult = 7;

        // 2. Act
        int actualResult = calculator.add(firstNumber, secondNumber);

        // 3. Assert
        assertEquals(expectedResult, actualResult, "sum of 3 and 4 should be 7");
    }


    @Test
    void testGetLastResultInitialValue() {

        // 1. Arrange
        int expectedResult = 0;

        // 2. Act
        int actualResult = calculator.getLastResult();

        // 3. Assert
        assertEquals(expectedResult, actualResult, "initial last result should be 0");
    }

    @Test
    void testGetLastResultAfterOneUpdate() {
        
        // 1. Arrange
        int x = 3;
        int y = 2;
        int expectedResult = 5;

        // 2. Act 
        calculator.add(x,y);
        int actualResult = calculator.getLastResult();

        // 3. Assert
        assertEquals(expectedResult, actualResult, 
            "last result after calculating 3 + 2 should be 5");
    }

}
