package com.example;

/**
 * 
 * Main class
 */
public class Calculator {

    // lastResult
    private int lastResult = 0;

    /**
     * Calculates the sum of two integers
     * @param a the first integer
     * @param b the second integer
     * @return the sum of the two integers
     */
    public int add(int a, int b) {        
        return a + b;
    }

    /**
     * Getter for last result
     * @return last result
     */
    public int getLastResult() {
        return lastResult;
    }

    /**
     * Questions / Excercises
     *      1. Modify the code so that all tests pass
     *      2. Add a method to subract two numbers
     *      3. Add a Junit test by doing the following:
     *          (a) Right click anywhere in this file and select 
     *              Source Action --> GenerateTests
     *          (b) Type the target class name com.example.CalculatorTest if
     *              if necessary and hit Enter
     *          (c) Modify the test
     *    *      
     */

    // 
  
}