package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * 
 * The example Application. You must override start. 
 * 
 */
public class App extends Application {

    /**
     * Main entry point for all JavaFX applications
     * @stage the primary stage for the application
     * @see javafx.application.Application#start(javafx.stage.Stage)
     */
    @Override
    public void start(Stage stage) {

        // Create vertical box (VBox) which will contain 3 buttons        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));
        leftPane.setAlignment(Pos.TOP_CENTER);
        leftPane.setStyle("-fx-background-color: #e8e8e8;");
        leftPane.setPrefWidth(120); 

        // for each button
        for (int i = 1; i <= 3; i++) {

            // create the button object
            Button b = new Button("Click " + i);

            // set the max width to allow for infinite growth
            //      (constrained by the parent)
            b.setMaxWidth(Double.MAX_VALUE);                         

            if (i != 3) {   // if not the 3rd button

                // set action to toggle button text
                b.setOnAction(e -> {
                    String text = b.getText();
                    if (text.contains("Click")) {
                        text = text.replace("Click", "Button");
                    } else {
                        text = text.replace("Button", "Click");
                    }
                    b.setText(text);                    
                });
            }
            else  { // if the third button
                
                // set action to generate an alert
                b.setText("Alert");
                b.setOnAction(e -> {
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Message");
                    alert.setHeaderText(null);          // removes the large header area
                    alert.setContentText("Hello World");
                    alert.showAndWait(); // pause code until closed
                });                
            }

            // add button the left pane
            leftPane.getChildren().add(b);            

        }

        // Create text area input
        TextArea input = new TextArea();
        input.setPromptText("Type something...");
        input.setWrapText(true); // disable horizontal scroll

        // create label that mirrors text input
        Label output = new Label();
        output.textProperty().bind(input.textProperty());

        // create a GridPane layout (rows and columns)
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));
        
        // add label to first column and first row
        grid.add(new Label("Input:"), 0, 0);
        // add text input to second column and first row
        grid.add(input, 1, 0);
        // add label to first column and second row
        grid.add(new Label("Output:"), 0, 1);
        // add output to second column and second row
        grid.add(output, 1, 1);

        // Create a BorderPane which has a top, buttom, left, right, and center
        // This border pane will serve as the root for the stage
        // see https://docs.oracle.com/javase/8/javafx/api/javafx/scene/layout/BorderPane.html
        BorderPane root = new BorderPane();

        // set the left and center panels
        root.setLeft(leftPane);
        root.setCenter(grid);     
           
        // Create a new scene with the border pane root
        Scene scene = new Scene(root, 800, 300);
        stage.setScene(scene);
        stage.setTitle("CSC 360, JavaFX Example");
    
        // Show the scene
        stage.show();                        
    }

    /**
     * Main method which launches the JavaFX application
     * @param args not used
     */
    public static void main(String[] args) {
        launch(args);        
    }


    /**
     * Exercises
     * 
     * 1. Change the font size of each button to 16.
     * 2. What happens if you set the root as the grid? How can you set the root correctly?
     * 3. Add a button below the input text area that spans 3 columns.
     *          Clicking the button clears the input.
     * 4. Add a drop down above the input that allows you change the
     *      font color between black, red, and blue.
     *    Notes: (1) ComboBox is a generic; 
     *           (2) you can use the setOnAction method of the ComboBox to
     *               respond to selection changes. Use Color.web(selected) to
     *               set the color.
     * 
     */

}