package com.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class CalendarTest {

    // set up parameterized test (set name for each test)
    @ParameterizedTest(name = "{0} -> {1}") 

    // each set of arguments is in quotes
    @CsvSource({
        "Monday, M",        
        "Tuesday, T",
        "Wednesday, W",
        "Thursday, R",
        "Friday, F",
        "Saturday, S",
        "Sunday U"
    })
    
    void testAbbreviateDayValid(String day, String expected) {

        // Act
        String actual =  Calendar.abbreviateDay(day);

        // Assert
        assertEquals(expected, actual);

    }
}
