package com.example;

public final class Calendar {
   
    // explicit constructor, should not be called
    private Calendar() {
        // utility class, cannot be called
    }

    public static String abbreviateDay(String day) {
        switch(day) {
            case "Monday":
                return "M";
            case "Tuesday":
                return "T";
            case "Wednesday" :
                return "W";
            case "Thursday":
                return "R";
            case "Friday" :
                return "F";               
            default: 
                throw new IllegalArgumentException("Day " + day + " is not valid");
        }
    }


    public static String abbreviateMonth(String month) {
        return month;
    }

}