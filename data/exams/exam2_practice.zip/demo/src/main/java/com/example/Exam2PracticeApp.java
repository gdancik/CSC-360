package com.example;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Exam2PracticeApp extends Application {

    private static final double STOP_SECONDS = 4.0;
    private static final double WIDTH = 400;
    private static final double HEIGHT = 300;

    private GraphicsContext gc;
    private Label myLabel;
    private Button myButton;
    private AnimationTimer timer;

    @Override
    public void start(Stage stage) {
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.RED);
        gc.setLineWidth(4);

        myLabel = new Label();
        myLabel.setFont(Font.font(32));

        myButton = new Button("Start");
        myButton.setOnAction(e -> onButtonPressed());

        drawSomething(0);

        timer = new AnimationTimer() {
            private long startTime = -1;

            @Override
            public void handle(long now) {
                if (startTime < 0) {
                    startTime = now;
                }

                double elapsed = (now - startTime) / 1_000_000_000.0;

                if (elapsed >= STOP_SECONDS) {
                    drawSomething(STOP_SECONDS);
                    stop();
                    return;
                }
                drawSomething(elapsed);
            }

            @Override
            public void stop() {
                super.stop();
                startTime = -1; 
            }
        };
        
        VBox root = new VBox(10, myLabel, canvas, myButton);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(10));

        stage.setScene(new Scene(root));
        stage.setTitle("Line Animation");
        stage.show();
    }

    private void onButtonPressed() {
        if (myButton.getText().equals("Start")) {            
            myButton.setText("Reset");
            timer.start();
        } else {            
            myButton.setText("Start");
            timer.stop();
            drawSomething(0);
        }
    }

    private void drawSomething(double elapsed) {

        double progress = elapsed / STOP_SECONDS;

        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, WIDTH, HEIGHT);
        gc.strokeLine(0, HEIGHT / 2, WIDTH * progress, HEIGHT / 2);
        
        double r = STOP_SECONDS - elapsed;

        String formatted = String.format("%.1f", r);
        myLabel.setText(formatted);
    }

    public static void main(String[] args) {
        launch(args);
    }
}